#!/usr/bin/env python
# -*- coding: utf-8 -*-

################################################################################
# Copyright 2017 ROBOTIS CO., LTD.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
################################################################################

# Author: Ryu Woon Jung (Leon)

#
# *********     Read and Write Example      *********
#
#
# Available DXL model on this example : All models using Protocol 1.0
# This example is designed for using a Dynamixel MX-28, and an USB2DYNAMIXEL.
# To use another Dynamixel model, such as X series, see their details in E-Manual(support.robotis.com) and edit below variables yourself.
# Be sure that Dynamixel MX properties are already set as ## ID : 1 / Baudnum : 34 (Baudrate : 57600)
#

import os
import math
import cmath
import time
if os.name == 'nt':
    import msvcrt
    def getch():
        return msvcrt.getch().decode()
else:
    import sys, tty, termios
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    def getch():
        try:
            tty.setraw(sys.stdin.fileno())
            ch = sys.stdin.read(1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        return ch

os.sys.path.append('../dynamixel_functions_py')             # Path setting

import dynamixel_functions as dynamixel                     # Uses Dynamixel SDK library

# Control table address
ADDR_MX_TORQUE_ENABLE       = 24                            # Control table address is different in Dynamixel model
ADDR_MX_GOAL_POSITION       = 30
ADDR_MX_PRESENT_POSITION    = 36

# Protocol version
PROTOCOL_VERSION            = 1                             # See which protocol version is used in the Dynamixel

# Default setting
DXL_ID                      = 1                             # Dynamixel ID: 1
MOTOR1_ID                   = 6
MOTOR2_ID                   = 14
MOTOR3_ID                   = 4
MOTOR4_ID                   = 11
BAUDRATE                    = 1000000
DEVICENAME                  = "COM6".encode('utf-8')                       # Check which port is being used on your controller
                                                            # ex) Windows: "COM1"   Linux: "/dev/ttyUSB0" Mac: "/dev/tty.usbserial-*"

TORQUE_ENABLE               = 1                             # Value for enabling the torque
TORQUE_DISABLE              = 0                             # Value for disabling the torque
DXL_MINIMUM_POSITION_VALUE  = 100                           # Dynamixel will rotate between this value
DXL_MAXIMUM_POSITION_VALUE  = 4000                          # and this value (note that the Dynamixel would not move when the position value is out of movable range. Check e-manual about the range of the Dynamixel you use.)
DXL_MOVING_STATUS_THRESHOLD = 10                            # Dynamixel moving status threshold

ESC_ASCII_VALUE             = 0x1b

COMM_SUCCESS                = 0                             # Communication Success result value
COMM_TX_FAIL                = -1001                         # Communication Tx Failed

# Initialize PortHandler Structs
# Set the port path
# Get methods and members of PortHandlerLinux or PortHandlerWindows
port_num = dynamixel.portHandler(DEVICENAME)

# Initialize PacketHandler Structs
dynamixel.packetHandler()

index = 0
dxl_comm_result = COMM_TX_FAIL                              # Communication result
dxl_goal_position = [DXL_MINIMUM_POSITION_VALUE, DXL_MAXIMUM_POSITION_VALUE]         # Goal position

dxl_error = 0                                               # Dynamixel error
dxl_present_position = 0                                    # Present position

def move (x, y, z):
    phi = 97
    l1 = 8.4
    l2 = 10.5
    l3 = 9.4
    l4 = 10.5
    ratio = (512-211)/90
    deltaZ = z - l1 + l4*math.sin(math.radians(phi))
    deltaR = math.pow(math.pow(x,2) + math.pow(y,2),0.5)-l4*math.cos(math.radians(phi))
    beta = math.degrees(math.atan2(deltaZ, deltaR))
    psi = math.degrees(math.acos((math.pow(l3,2) - math.pow(deltaZ,2) - math.pow(deltaR,2) - math.pow(l2,2))/((-2)*(l2)*(math.pow(math.pow(deltaZ,2) + math.pow(deltaR,2),0.5)))))


    theta1 = math.degrees(math.atan2(y,x))
    theta3 = math.degrees(math.acos((math.pow(deltaZ,2) + math.pow(deltaR,2) - math.pow(l2,2) - math.pow(l3,2))/(2*l2*l3)))
    theta2 = (90) - beta - psi
    theta4 = phi - theta2 - theta3 + (90)

    angle1 = int(512 - (theta1)*ratio)
    angle2 = int(512 - (theta2)*ratio)
    angle3 = int(512 - (theta3)*ratio)
    angle4 = int(512 - (theta4)*ratio)

        #if getch() == chr(ESC_ASCII_VALUE):
         #   break

        # Write goal position
    dynamixel.write2ByteTxRx(port_num, PROTOCOL_VERSION, MOTOR1_ID, ADDR_MX_GOAL_POSITION, angle1)
    dynamixel.write2ByteTxRx(port_num, PROTOCOL_VERSION, MOTOR2_ID, ADDR_MX_GOAL_POSITION, angle2)
    dynamixel.write2ByteTxRx(port_num, PROTOCOL_VERSION, MOTOR3_ID, ADDR_MX_GOAL_POSITION, angle3)
    dynamixel.write2ByteTxRx(port_num, PROTOCOL_VERSION, MOTOR4_ID, ADDR_MX_GOAL_POSITION, angle4)
def goalmove(x,y,z,goalx,goaly,goalz):
    diffx = math.floor(goalx - x)
    diffy = math.floor(goaly - y)
    defaultz = 9
    diffz = math.floor(goalz - defaultz)
    intialz = defaultz - z
    # This first block always brings the arm up vertically first before moving horizontally
    tempz = z
    if intialz > 0:
        for i in range(0, abs(intialz) * 2):
            tempz = tempz + intialz / (abs(intialz) * 2)
            move(x, y, tempz)
            time.sleep(0.03)
            print(tempz)
        z = tempz


    tempx = x
    for i in range(0, abs(diffx) * 2):
        tempx = tempx + diffx / (abs(diffx) * 2)
        move(tempx, y, z)
        time.sleep(0.03)
        print(tempx)
    x = tempx


    tempy = y
    for i in range(0, abs(diffy) * 2):
        tempy = tempy + diffy / (abs(diffy) * 2)
        move(x, tempy, z)
        time.sleep(0.03)
        print(tempy)
    y = tempy

    tempz = z
    for i in range(0, abs(diffz) * 2):
        tempz = tempz + diffz / (abs(diffz) * 2)
        move(x, y, tempz)
        time.sleep(0.03)
        print(tempz)
    z = tempz

# Open port
if dynamixel.openPort(port_num):
    print("Succeeded to open the port!")
else:
    print("Failed to open the port!")
    print("Press any key to terminate...")
    getch()
    quit()

# Set port baudrate
if dynamixel.setBaudRate(port_num, BAUDRATE):
    print("Succeeded to change the baudrate!")
else:
    print("Failed to change the baudrate!")
    print("Press any key to terminate...")
    getch()
    quit()


# Enable Dynamixel Torque
dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, DXL_ID, ADDR_MX_TORQUE_ENABLE, TORQUE_ENABLE)
dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)
dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)
if dxl_comm_result != COMM_SUCCESS:
    print(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result))
elif dxl_error != 0:
    print(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error))
else:
    print("Dynamixel has been successfully connected")

x=13
y=0
z = 9
move(x,y,z)
goalx = 10.5
goaly = 5
goalz = -3 #required height for button to be pushed
goalmove(x,y,z,goalx,goaly,goalz)
#pickup point
goalx2 = 13
goaly2 = -4
goalz2 = -4
goalmove(goalx,goaly,goalz,goalx2,goaly2,goalz2)
#dropoff point
goalx3 = 13
goaly3 = 0
goalz3 = 9
goalmove(goalx2, goaly2,goalz2,goalx3,goaly3,goalz3)

while (True):
    dynamixel.write2ByteTxRx(port_num, PROTOCOL_VERSION, DXL_ID, ADDR_MX_GOAL_POSITION, dxl_goal_position[index])
    dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)
    dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)
    if dxl_comm_result != COMM_SUCCESS:
        print(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result))
    elif dxl_error != 0:
        print(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error))

    while 1:
        # Read present position
        dxl_present_position = dynamixel.read2ByteTxRx(port_num, PROTOCOL_VERSION, DXL_ID, ADDR_MX_PRESENT_POSITION)
        dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)
        dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)
        if dxl_comm_result != COMM_SUCCESS:
            print(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result))
        elif dxl_error != 0:
            print(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error))

        print("[ID:%03d] GoalPos:%03d  PresPos:%03d" % (DXL_ID, dxl_goal_position[index], dxl_present_position))

        if not (abs(dxl_goal_position[index] - dxl_present_position) > DXL_MOVING_STATUS_THRESHOLD):
            break

    # Change goal position
    if index == 0:
        index = 1
    else:
        index = 0


# Disable Dynamixel Torque
dynamixel.write1ByteTxRx(port_num, PROTOCOL_VERSION, DXL_ID, ADDR_MX_TORQUE_ENABLE, TORQUE_DISABLE)
dxl_comm_result = dynamixel.getLastTxRxResult(port_num, PROTOCOL_VERSION)
dxl_error = dynamixel.getLastRxPacketError(port_num, PROTOCOL_VERSION)
if dxl_comm_result != COMM_SUCCESS:
    print(dynamixel.getTxRxResult(PROTOCOL_VERSION, dxl_comm_result))
elif dxl_error != 0:
    print(dynamixel.getRxPacketError(PROTOCOL_VERSION, dxl_error))


# Close port
dynamixel.closePort(port_num)




